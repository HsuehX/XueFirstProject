package org.sang.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.sang.client.utils.PermissionUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements View.OnClickListener, PermissionUtils.PermissionGrant {
    Button add;
    private TextView mShowTv;

    private IBinder mRemote;

    private Button mThreadBtn;
    private TextView mShowThreadTv;
    private Spinner mTypeSp;
    private EditText mFileNameEt;
    private ScrollView mReadSV;
    private TextView mShowReadTextTv;
    private ScrollView mInputSV;
    private EditText mInputEt;
    private Button mConfirmBtn;
    private EditText mNewFileNameEt;


    private List<String> typeList = new ArrayList<>();
    private ArrayAdapter<String> mSimpleAdapter;
    String chooseType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

    }

    private void init() {
        checkUriPermission(this, this);
        initView();
        typeList.add("READ LINE BY BUFFERREADER");
        typeList.add("READ BY FILEINPUTSTREAM");
        typeList.add("CREATE");
        typeList.add("WRITE RANDOMACCESSFILE");
        typeList.add("WRITE FILEOUTPUTSTREAM");
        typeList.add("WRITE BUFFEREDWRITER");
        typeList.add("DELETE_CONTENT");
        typeList.add("DELETE_ANYONE");
        typeList.add("DELETE_FILE");
        typeList.add("DELETE_FOLDER");
        typeList.add("RENAME");
        mSimpleAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, typeList);
        mSimpleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mTypeSp.setAdapter(mSimpleAdapter);
        mReadSV.setVisibility(View.GONE);
        mInputSV.setVisibility(View.GONE);

        mTypeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                chooseType = typeList.get(i);
                switch (chooseType) {
                    case "READ LINE BY BUFFERREADER":
                        viewReadState();
                        break;
                    case "READ LINE BY FILEINPUTSTREAM":
                        viewReadState();
                        break;
                    case "WRITE RANDOMACCESSFILE":
                        viewWriteState();
                        break;
                    case "WRITE FILEOUTPUTSTREAM":
                        viewWriteState();
                        break;
                    case "WRITE BUFFEREDWRITER":
                        viewWriteState();
                        break;
                    case "CREATE":
                        viewCreatOrDel();
                        break;
                    case "DELETE_CONTENT":
                        viewCreatOrDel();
                        break;
                    case "DELETE_ANYONE":
                        viewCreatOrDel();
                        break;
                    case "DELETE_FILE":
                        viewCreatOrDel();
                        break;
                    case "DELETE_FOLDER":
                        viewCreatOrDel();
                        break;
                    case "RENAME":
                        mFileNameEt.setVisibility(View.VISIBLE);
                        mReadSV.setVisibility(View.GONE);
                        mInputSV.setVisibility(View.GONE);
                        mNewFileNameEt.setVisibility(View.VISIBLE);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    private void initView() {
        add = (Button) findViewById(R.id.add);
        mShowTv = (TextView) findViewById(R.id.tv_show);
        mThreadBtn = (Button) findViewById(R.id.btn_start_thread);
        mShowThreadTv = (TextView) findViewById(R.id.tv_show_read_text);
        mFileNameEt = (EditText) findViewById(R.id.et_file_name);
        mTypeSp = (Spinner) findViewById(R.id.sp_type);
        mReadSV = (ScrollView) findViewById(R.id.sv_read);
        mShowReadTextTv = (TextView) findViewById(R.id.tv_show_read_text);
        mInputSV = (ScrollView) findViewById(R.id.sv_input);
        mInputEt = (EditText) findViewById(R.id.et_input);
        mConfirmBtn = (Button) findViewById(R.id.btn_confirm);
        mNewFileNameEt = (EditText) findViewById(R.id.et_new_file_name);

        mThreadBtn.setOnClickListener(this);
        mConfirmBtn.setOnClickListener(this);

        Intent intent = new Intent("myaddservice");
        intent.setPackage("org.sang.host");
        boolean b = bindService(intent, new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                //这个service就是Binder驱动中创建的Binder对象
                mRemote = service;
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        }, Service.BIND_AUTO_CREATE);
        add.setEnabled(b);
    }

    private void viewReadState() {
        mFileNameEt.setVisibility(View.VISIBLE);
        mReadSV.setVisibility(View.VISIBLE);
        mInputSV.setVisibility(View.GONE);
        mNewFileNameEt.setVisibility(View.GONE);
    }

    private void viewWriteState() {
        mFileNameEt.setVisibility(View.VISIBLE);
        mReadSV.setVisibility(View.GONE);
        mInputSV.setVisibility(View.GONE);
        mNewFileNameEt.setVisibility(View.GONE);
    }

    private void viewCreatOrDel() {
        mFileNameEt.setVisibility(View.VISIBLE);
        mReadSV.setVisibility(View.GONE);
        mInputSV.setVisibility(View.GONE);
        mNewFileNameEt.setVisibility(View.GONE);
    }

    public void add(View view) {
        int code = 1;
        //向服务端发送的数据
        Parcel data = Parcel.obtain();
        //接收服务端返回的数据
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken("MyAddBinder");
        data.writeInt(10);
        data.writeInt(9);
        try {
            mRemote.transact(code, data, reply, 0);
            int i = reply.readInt();
            Log.d("google.sang", "add: " + i);
            mShowTv.setText("" + i);
            reply.recycle();
            data.recycle();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_start_thread:
//                TestThread testThread = new TestThread();
//                testThread.start();
                final TestTTTThread testThread = new TestTTTThread();
                Handler mHandler = new Handler();
                Runnable mRunnable = new Runnable() {
                    public void run() {
                        testThread.interrupt();
                    }
                };
                mHandler.postDelayed(mRunnable, 30 * 1000);
                testThread.start();

                break;

            case R.id.btn_confirm:
                saveFile(chooseType, mFileNameEt.getText().toString());
                break;
            default:
                break;
        }
    }


    public class TestThread extends Thread {
        public void run() {
            while (true) {
                try {
                    sleep(1000);
                    System.out.println("一秒运行一次");
//                    mShowThreadTv.setText(mShowThreadTv.getText() + "\r\n" + "一秒运行一次");
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }
    }

    public class TestTTTThread extends Thread {
        public void run() {
            int i = 0;
            while (i < 10) {
                try {
                    sleep(1000);
                    System.out.println("一秒运行一次" + i);
//                    mShowThreadTv.setText(mShowThreadTv.getText() + "\r\n" + "一秒运行一次");
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                i++;
            }
        }
    }

    /**
     * @param args
     */
    public void main(String[] args) {
        // TODO Auto-generated method stub
        TestThread testThread = new TestThread();
        testThread.start();
    }


    public class MyThread extends Thread {
        public void run() {
            super.run();
            try {
                if (this.interrupted()) {
                    System.out.println("线程已经终止， for循环不再执行");
                    throw new InterruptedException();
                }
                sleep(1000);
                System.out.println("一秒运行一次");

//                System.out.println("i=" + (i + 1));
                System.out.println("这是for循环外面的语句，也会被执行");
            } catch (InterruptedException e) {
                System.out.println("进入MyThread.java类中的catch了。。。");
                e.printStackTrace();
            }
        }
    }


    /**
     * data/data: context.getFileDirs().getPath();
     * 　　是一个应用程序的私有目录，只有当前应用程序有权限访问读写，其他应用无权限访问。一些安全性要求比较高的数据存放在该目录，一般用来存放size比较小的数据。
     * <p>
     * sdcard:  Enviroment.getExternalStorageDirectory().getPath();
     * 　　是一个外部存储目录，只用应用声明了<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>的一个权限，
     * 就可以访问读写sdcard目录；所以一般用来存放一些安全性不高的数据，文件size比较大的数据。
     */


    private void systemDialog(String showText) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage(showText + "");
        dialog.show();
    }

    /**
     * 文件io
     */
    private void saveFile(String type, String fileName) {
        String fileString = String.valueOf(MainActivity.this.getFilesDir());
        String filePath = Environment.getExternalStorageDirectory() + File.separator + "/" + getPackageName();
//        String filePath = Environment.getExternalStorageDirectory() + "";
//        String fileName = "TestFile.txt";
//        File file = new File(fileString + fileName);
        createFolder(filePath);
        File file = new File(filePath + "/" + fileName);


        if (!TextUtils.isEmpty(type) && type.equalsIgnoreCase("create")) {
            if (!file.exists()) {//文件是否存在
                try {
                    file.createNewFile();
                    systemDialog("创建成功！");
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.i("error", e + "");
                }
            } else {
                systemDialog("文件已存在！");
            }
            return;
        }

        if (!TextUtils.isEmpty(type)) {
            if (!TextUtils.isEmpty(fileName) && !"WRITE FILEOUTPUTSTREAM".equalsIgnoreCase(type)) {
                if (!file.exists()) {//文件是否存在
                    systemDialog("文件不存在！");
                } else {
                    if (type.equalsIgnoreCase("READ LINE BY BUFFERREADER")) {
                        readBufferedReader(file, false);
                    } else if (type.equalsIgnoreCase("READ BY FILEINPUTSTREAM")) {
                        readFileInputStream(file);
                    } else if (type.equalsIgnoreCase("WRITE RANDOMACCESSFILE")) {
                        writeRandomAccessFile(file, mInputEt.getText().toString());
                    } else if (type.equalsIgnoreCase("WRITE BUFFEREDWRITER")) {
                        writeBufferedWriter(file, mInputEt.getText().toString());
                    } else if (type.equalsIgnoreCase("DELETE_CONTENT")) {
                        readBufferedReader(file, true);//读取并按行删除
                    } else if (type.equalsIgnoreCase("DELETE_ANYONE")) {
                        deleteAnyone(file + "");
                    } else if (type.equalsIgnoreCase("DELETE_FILE")) {
                        deleteOnlyFile(file + "");
                    } else if (type.equalsIgnoreCase("DELETE_FOLDER")) {
                        deleteFolder(file + "");
                    } else if (type.equalsIgnoreCase("RENAME")) {
                        rename(file, mNewFileNameEt.getText().toString());
                    }
                }
            } else if (TextUtils.isEmpty(fileName) && "WRITE FILEOUTPUTSTREAM".equalsIgnoreCase(type)) {
                writeFileOutputStream(mInputEt.getText().toString());
            } else {
                systemDialog("文件不存在！");
            }
            return;
        }
    }

    /**
     * RandomAccessFile写入
     */
    private void writeRandomAccessFile(File file, String writeContent) {
        try {
            RandomAccessFile raf = new RandomAccessFile(file, "rwd");//实现一个文件随机读取的对象，并赋予读写的权限
            raf.seek(file.length());//移动当前RandomAccessFile的指针位置
            raf.write(writeContent.getBytes());//字符串转化成字节
            raf.close();
            systemDialog("写入成功！");
            mInputEt.setText("");
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("error", e + "");
        }
    }

    /**
     * FileOutputStream写入
     * 覆盖原本内容（先清空原有内容，再写入）
     * openFileOutput()方法的第一参数用于指定文件名称，不能包含路径分隔符“/” ，如果文件不存在，Android 会自动创建它。
     * 创建的文件保存在/data/data/<package name>/files目录。
     * <p>
     * 第二参数用于指定操作模式，有四种模式
     * Context.MODE_PRIVATE    = 0 操作    默认操作模式  写入的内容会覆盖原文件的内容
     * 　Context.MODE_APPEND    =  32768     模式会检查文件是否存在，存在就往文件追加内容，否则就创建新文件
     * 用来控制其他应用是否有权限读写该文件
     * 　Context.MODE_WORLD_READABLE =  1    表示当前文件可以被其他应用读取
     * 　Context.MODE_WORLD_WRITEABLE =  2   表示当前文件可以被其他应用写入
     */
    //这个就选择了向指定的文件中写入指定的数据
    public void writeFileOutputStream(String writeContent) {
        try {
            FileOutputStream fos = this.openFileOutput("test.txt", MODE_PRIVATE);
            byte[] bytes = writeContent.getBytes();
            fos.write(bytes);
            fos.close();
            systemDialog("写入成功！");
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("error", e + "");
        }
    }

    /**
     * BufferedWriter
     * Writer类就是为写文本而设计的。使用BufferedWriter写入文本时不需要将文本转换成字节数组.
     */
    private void writeBufferedWriter(File file, String writeString) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            //使用缓冲区中的方法将数据写入到缓冲区中。
            bw.write(writeString);
            bw.newLine();
            //使用缓冲区中的方法，将数据刷新到目的地文件中去。
            bw.flush();
            //关闭缓冲区,同时关闭了FileWriter流对象
            bw.close();
            systemDialog("写入成功！");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * BufferedReader读取
     * 这里要注意在manifest找那个添加 android:largeHeap="true" 否则会报内存异常的错误
     */
    private void readBufferedReader(File file, boolean isDeleteLine) {
        ArrayList list = new ArrayList();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String readline = "";
            StringBuffer sb = new StringBuffer();
            while ((readline = br.readLine()) != null) {//按行读取 如果当前读取的行 内容不为空
                sb.append(readline + "\n");//将读取的内容追加进字符串
                list.add(readline);
            }
            br.close();
            mShowReadTextTv.setText(sb + "");
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("error", e + "");
        }

        if (isDeleteLine) {
            deleteLine(file, list);
        }
    }


    /**
     * FileInputStream读取
     */
    private void readFileInputStream(File file) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] readBuffer = new byte[fileInputStream.available()];
            fileInputStream.read(readBuffer);
            fileInputStream.close();
            String readResult = new String(readBuffer, "UTF-8");
            mShowReadTextTv.setText(readResult + "");
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("error", e + "");
        }
    }

    /**
     * 创建文件夹
     */
    private void createFolder(String filePath) {
        File file = null;
        try {
            file = new File(filePath);
            if (!file.exists()) {
                file.mkdir();
            }
        } catch (Exception e) {
            Log.i("error", e + "");
        }
    }

    /**
     * 按行删除内容
     */
    private void deleteLine(File file, ArrayList<String> list) {
        list.remove(0);//删除第一行
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
            BufferedWriter bw = new BufferedWriter(outputStreamWriter);
            if (list.size() != 0) {
                for (String content : list) {
                    bw.write(content);
                    bw.newLine();
                }
            } else {
                bw.write("");
            }
            bw.flush();
            bw.close();
            systemDialog("删除成功！");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 删除DELETE_ANYONE
     * 删除文件，可以是文件或文件夹
     * <p>
     * Java中isFile与exists()的区别：
     * 在Linux中，区别比较明显，对于/dev/null 文件是特殊文件，isFile返回false，而exist返回true
     * isFile()
     * public boolean isFile()测试此抽象路径名表示的文件是否是一个标准文件。
     * 抛出:SecurityException,如果存在安全管理器,且其SecurityManager.checkRead(java.lang.String)方法拒绝对文件进行读访问。
     * exists()
     * public boolean exists()测试此抽象路径名表示的文件或目录是否存在。
     * 抛出:SecurityException如果存在安全管理器,且其SecurityManager.checkRead(java.lang.String)方法拒绝对文件或目录进行写访问。
     */
    private void deleteAnyone(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            systemDialog("删除失败，文件不存在！");
        } else {
            if (file.isFile()) {
                deleteFile(fileName);//如果是一个文件 只删除文件
                systemDialog("删除成功！");
            } else {
                //如果是一个文件夹，删除文件夹及其下面所有的子文件
            }
        }
    }

    /**
     * 删除文件
     */
    private void deleteOnlyFile(String fileName) {
        File file = new File(fileName);
        if (file.exists() && file.isFile()) {
            if (file.delete()) {
                systemDialog("删除单个文件成功！");
            } else {
                systemDialog("删除单个文件失败！");
            }
        } else {
            systemDialog("删除失败，文件不存在！");
        }
    }


    /**
     * 删除文件夹
     */
    private boolean deleteFolder(String filePath) {
        // 如果filePath不以文件分隔符结尾，自动添加文件分隔符    separator分割器
        if (!filePath.endsWith(File.separator)) {
            filePath = filePath + File.separator;
            File file = new File(filePath);
            // 如果dir对应的文件不存在，或者不是一个目录，则退出
            if (!file.exists() || !file.isDirectory()) {
                systemDialog("删除失败，文件不存在！");
            } else {
                boolean flag = true;
                // 删除文件夹中的所有文件包括子目录
                File[] files = file.listFiles();
                for (int i = 0; i < filePath.length(); i++) {
                    //如果目录中含有子文件
                    if (files[i].isFile()) {
                        deleteOnlyFile(files[i].getAbsolutePath());//调用上面写的那个删除文件的方法 先将文件夹里的所有子文件删除
                        //如果删除失败 跳出
                        if (flag) {
                            break;
                        }
                    } else if (files[i].isDirectory()) {//如果含有子文件夹
                        flag = deleteFolder(files[i].getAbsolutePath());//调用本身，将子文件夹中的所有子文件删除
                        if (flag) {
                            break;
                        }
                    }
                }

                if (flag) {
                    systemDialog("删除失败！");
                } else {
                    if (file.delete()) {
                        systemDialog("删除成功！");
                    }
                }
            }
        }
        return false;
    }

    /**
     * 重命名
     */
    private void rename(File oldFile, String newName) {
        File newFile = new File(Environment.getExternalStorageDirectory() + File.separator + "/" + getPackageName() + "/" + newName);
        if (!oldFile.exists()) {
            systemDialog("没有这个文件!");
        } else if (newFile.exists()) {
            systemDialog("已存在同名文件！");
        } else {
            oldFile.renameTo(newFile);
            systemDialog("修改成功！");
        }
    }


    /****
     *动态加载，下面的方法显示的是系统自带的提示
     */
    protected boolean checkUriPermission(Activity activity, PermissionUtils.PermissionGrant grant) {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int permission0 = checkSelfPermission(PermissionUtils.requestPermissions[0]);
            int permission1 = checkSelfPermission(PermissionUtils.requestPermissions[1]);
            int permission2 = checkSelfPermission(PermissionUtils.requestPermissions[2]);

            if (permission0 != PackageManager.PERMISSION_GRANTED
                    || permission1 != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, PermissionUtils.requestPermissions, PermissionUtils.CODE_MULTI_PERMISSION);
                requestPermissions(PermissionUtils.requestPermissions, PermissionUtils.CODE_MULTI_PERMISSION);
                return false;
            }

            return true;
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionUtils.requestPermissionsResult(this, requestCode, permissions, grantResults, mPermissionGrant);
        switch (requestCode) {
            case PermissionUtils.CODE_MULTI_PERMISSION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
                        && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                } else {
                    finish();
                }
                break;
            default:
                break;
        }
    }

    private PermissionUtils.PermissionGrant mPermissionGrant = new PermissionUtils.PermissionGrant() {
        @Override
        public void onPermissionGranted(int requestCode) {
        }
    };

    @Override
    public void onPermissionGranted(int requestCode) {

    }

}
